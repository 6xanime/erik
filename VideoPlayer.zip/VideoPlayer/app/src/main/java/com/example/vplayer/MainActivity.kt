package com.example.vplayer

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Size
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private val Red = Color(0xFFFF1A3C)
private val Ring = Color(0x66FFFFFF)
private val Bg = Color(0xFF0B0B0C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } }
    }
}

data class Vid(val uri: Uri, val name: String, val dur: Long, val size: Long, val folder: String)

fun loadVideos(ctx: Context): List<Vid> {
    val out = mutableListOf<Vid>()
    val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    val proj = arrayOf(
        MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DURATION,
        MediaStore.Video.Media.SIZE, MediaStore.Video.Media.BUCKET_DISPLAY_NAME
    )
    ctx.contentResolver.query(base, proj, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
        while (c.moveToNext()) {
            out += Vid(ContentUris.withAppendedId(base, c.getLong(0)), c.getString(1) ?: "Video", c.getLong(2), c.getLong(3), c.getString(4) ?: "")
        }
    }
    return out
}

fun fmt(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = s % 3600 / 60
    val x = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, x) else "%02d:%02d".format(m, x)
}

fun Format.title(i: Int, kind: String): String {
    val lang = language?.takeIf { it != "und" }?.let { Locale.forLanguageTag(it).getDisplayLanguage(Locale.ENGLISH) }
    val ch = if (sampleMimeType?.startsWith("audio") == true && channelCount > 0) "${channelCount}ch" else null
    return listOfNotNull(label, lang, ch).distinct().joinToString(" · ").ifEmpty { "$kind ${i + 1}" }
}

fun addSub(ctx: Context, exo: ExoPlayer, uri: Uri) {
    val name = ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
    } ?: "subtitle.srt"
    val mime = when {
        name.endsWith(".vtt", true) -> MimeTypes.TEXT_VTT
        name.endsWith(".ass", true) || name.endsWith(".ssa", true) -> MimeTypes.TEXT_SSA
        else -> MimeTypes.APPLICATION_SUBRIP
    }
    val parts = name.substringBeforeLast('.').split('.')
    val lang = if (parts.size > 1 && parts.last().length in 2..3) parts.last() else null
    val sub = MediaItem.SubtitleConfiguration.Builder(uri).setMimeType(mime).setLanguage(lang).setLabel(name)
        .setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
    val item = exo.currentMediaItem ?: return
    val i = exo.currentMediaItemIndex
    val p = exo.currentPosition
    val old = item.localConfiguration?.subtitleConfigurations ?: emptyList()
    exo.replaceMediaItem(i, item.buildUpon().setSubtitleConfigurations(old + sub).build())
    exo.seekTo(i, p)
    exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build()
}

@Composable
fun App() {
    val act = LocalContext.current as ComponentActivity
    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
    var granted by remember { mutableStateOf(act.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) }
    var videos by remember { mutableStateOf(emptyList<Vid>()) }
    var idx by remember { mutableIntStateOf(-1) }
    var open by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    val player = remember {
        ExoPlayer.Builder(act, DefaultRenderersFactory(act).setEnableDecoderFallback(true)).build().also {
            // subtitles start switched off; the CC menu turns them on
            it.trackSelectionParameters = it.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
        }
    }
    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { idx = player.currentMediaItemIndex }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }
    LaunchedEffect(Unit) { if (!granted) ask.launch(perm) }
    LaunchedEffect(granted, tick) { if (granted) videos = withContext(Dispatchers.IO) { loadVideos(act) } }

    fun play(i: Int) {
        val items = videos.map { MediaItem.Builder().setUri(it.uri).setMediaMetadata(MediaMetadata.Builder().setTitle(it.name).build()).build() }
        player.setMediaItems(items, i, 0L)
        player.prepare()
        player.play()
        idx = i
        open = true
    }

    if (!open) Library(videos, granted, { ask.launch(perm) }, { tick++ }, ::play)
    else PlayerScreen(player, videos, idx, { player.seekTo(it, 0L) }) { player.stop(); player.clearMediaItems(); open = false }
}

@Composable
fun Thumb(v: Vid, mod: Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<android.graphics.Bitmap?>(null, v.uri) {
        value = withContext(Dispatchers.IO) { runCatching { ctx.contentResolver.loadThumbnail(v.uri, Size(320, 180), null) }.getOrNull() }
    }
    Box(mod.background(Color(0xFF222222))) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        Text(
            fmt(v.dur), color = Color.White, fontSize = 11.sp,
            modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp).background(Color(0xCC000000), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp)
        )
    }
}

@Composable
fun VRow(v: Vid, cur: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(if (cur) Color(0x22FFFFFF) else Color.Transparent).clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Thumb(v, Modifier.width(128.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(10.dp)))
        Spacer(Modifier.width(12.dp))
        Column {
            Text(v.name, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("${v.folder} · ${"%.1f".format(v.size / 1048576f)} MB", color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Composable
fun Library(videos: List<Vid>, granted: Boolean, onAsk: () -> Unit, onRefresh: () -> Unit, onOpen: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Videos", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("${videos.size} videos", color = Color.Gray)
            }
            IconButton(onRefresh) { Icon(Icons.Filled.Refresh, null, tint = Color.White) }
        }
        if (!granted) {
            Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                Text("Allow access once to see every video on this phone.", color = Color.Gray)
                Spacer(Modifier.height(16.dp))
                Button(onAsk) { Text("Allow access") }
            }
        } else LazyColumn { itemsIndexed(videos) { i, v -> VRow(v, false) { onOpen(i) } } }
    }
}

@Composable
fun Ib(icon: ImageVector, size: Dp = 40.dp, onClick: () -> Unit) {
    IconButton(onClick, Modifier.padding(horizontal = 3.dp).size(size).border(1.dp, Ring, CircleShape)) {
        Icon(icon, null, tint = Color.White)
    }
}

@Composable
fun BoxScope.Controls(
    exo: ExoPlayer, land: Boolean, title: String, playing: Boolean, pos: Long, dur: Long, drag: MutableState<Float?>,
    onMenu: (String) -> Unit, onLock: () -> Unit, onClose: () -> Unit, onFs: () -> Unit
) {
    Box(Modifier.matchParentSize().background(Color(0x66000000)))
    Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (land) Text(title, Modifier.weight(1f), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        else Spacer(Modifier.weight(1f))
        Ib(Icons.Filled.Subtitles) { onMenu("sub") }
        Ib(Icons.Filled.Audiotrack) { onMenu("audio") }
        Ib(Icons.Filled.Speed) { onMenu("speed") }
        Ib(Icons.Filled.Lock) { onLock() }
        Ib(Icons.Filled.Close) { onClose() }
    }
    Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(if (land) 24.dp else 8.dp)) {
        IconButton({ exo.seekToPrevious() }) { Icon(Icons.Filled.SkipPrevious, null, tint = Color.White) }
        Ib(Icons.Filled.Replay10, 48.dp) { exo.seekTo((exo.currentPosition - 10_000).coerceAtLeast(0)) }
        Ib(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, if (land) 72.dp else 56.dp) { if (playing) exo.pause() else exo.play() }
        Ib(Icons.Filled.Forward10, 48.dp) { exo.seekTo(exo.currentPosition + 10_000) }
        IconButton({ exo.seekToNext() }) { Icon(Icons.Filled.SkipNext, null, tint = Color.White) }
    }
    val frac = drag.value ?: if (dur > 0) pos.toFloat() / dur else 0f
    Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(fmt(pos), color = Color.White, fontSize = 12.sp)
        Slider(
            frac.coerceIn(0f, 1f), { drag.value = it }, Modifier.weight(1f).padding(horizontal = 6.dp),
            onValueChangeFinished = { drag.value?.let { exo.seekTo((it * dur).toLong()) }; drag.value = null },
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Red, inactiveTrackColor = Color(0xFF444444))
        )
        Text(fmt(dur), color = Color.White, fontSize = 12.sp)
        IconButton(onFs) { Icon(if (land) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen, null, tint = Color.White) }
    }
}

@Composable
fun PlayerScreen(exo: ExoPlayer, videos: List<Vid>, idx: Int, onJump: (Int) -> Unit, onClose: () -> Unit) {
    val act = LocalContext.current as ComponentActivity
    val land = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val scope = rememberCoroutineScope()
    var show by remember { mutableStateOf(true) }
    var locked by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(exo.isPlaying) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    val drag = remember { mutableStateOf<Float?>(null) }
    var menu by remember { mutableStateOf("") }
    var tracks by remember { mutableStateOf(exo.currentTracks) }
    var speed by remember { mutableFloatStateOf(1f) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) addSub(act, exo, u) }

    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onTracksChanged(t: Tracks) { tracks = t }
        }
        exo.addListener(l)
        act.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            exo.removeListener(l)
            act.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            WindowCompat.getInsetsController(act.window, act.window.decorView).show(WindowInsetsCompat.Type.systemBars())
        }
    }
    LaunchedEffect(Unit) { while (true) { pos = exo.currentPosition; dur = exo.duration.coerceAtLeast(0L); delay(300) } }
    LaunchedEffect(show, playing, menu, locked) { if (show && playing && menu.isEmpty()) { delay(3500); show = false } }
    LaunchedEffect(land) {
        val c = WindowCompat.getInsetsController(act.window, act.window.decorView)
        if (land) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else c.show(WindowInsetsCompat.Type.systemBars())
    }
    fun toggleFs() {
        scope.launch {
            if (land) {
                act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                delay(1200)
                act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            } else act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }
    BackHandler { if (land) toggleFs() else onClose() }

    val title = videos.getOrNull(idx)?.name ?: ""
    val box: @Composable (Modifier) -> Unit = { m ->
        Box(m.background(Color.Black).pointerInput(Unit) { detectTapGestures { show = !show } }) {
            AndroidView(
                factory = { c -> PlayerView(c).apply { player = exo; useController = false; resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT } },
                modifier = Modifier.fillMaxSize()
            )
            if (show && !locked) Controls(exo, land, title, playing, pos, dur, drag, { menu = it }, { locked = true }, onClose, { toggleFs() })
            if (show && locked) IconButton({ locked = false }, Modifier.align(Alignment.BottomEnd).padding(16.dp).border(1.dp, Ring, CircleShape)) {
                Icon(Icons.Filled.LockOpen, null, tint = Color.White)
            }
        }
    }
    if (land) box(Modifier.fillMaxSize())
    else Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
        box(Modifier.fillMaxWidth().aspectRatio(16f / 9f))
        Text(title, Modifier.padding(14.dp), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text("Up next", Modifier.padding(horizontal = 14.dp, vertical = 4.dp), color = Color.LightGray, fontWeight = FontWeight.SemiBold)
        LazyColumn { itemsIndexed(videos) { i, v -> VRow(v, i == idx) { onJump(i) } } }
    }

    if (menu.isNotEmpty()) {
        val opts = mutableListOf<Triple<String, Boolean, () -> Unit>>()
        val tp = exo.trackSelectionParameters
        val textOff = tp.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
        when (menu) {
            "audio" -> tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }.forEach { g ->
                for (i in 0 until g.length) opts += Triple(g.getTrackFormat(i).title(i, "Audio"), g.isTrackSelected(i), {
                    exo.trackSelectionParameters = tp.buildUpon().setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i)).build()
                })
            }
            "sub" -> {
                opts += Triple("Off", textOff, { exo.trackSelectionParameters = tp.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build() })
                tracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }.forEach { g ->
                    for (i in 0 until g.length) opts += Triple(g.getTrackFormat(i).title(i, "Subtitle"), g.isTrackSelected(i) && !textOff, {
                        exo.trackSelectionParameters = tp.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i)).build()
                    })
                }
                opts += Triple("+ Add subtitle file (.srt .vtt .ass)", false, { pick.launch(arrayOf("*/*")) })
            }
            else -> listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { sp ->
                opts += Triple("${sp}x", speed == sp, { speed = sp; exo.setPlaybackSpeed(sp) })
            }
        }
        AlertDialog(
            onDismissRequest = { menu = "" }, confirmButton = {},
            title = { Text(when (menu) { "audio" -> "Audio language"; "sub" -> "Subtitles"; else -> "Playback speed" }) },
            text = {
                LazyColumn {
                    if (opts.isEmpty()) item { Text("No tracks found") }
                    itemsIndexed(opts) { _, o ->
                        Text(
                            (if (o.second) "✓  " else "     ") + o.first,
                            Modifier.fillMaxWidth().clickable { menu = ""; o.third() }.padding(vertical = 12.dp),
                            color = if (o.second) Red else Color.White
                        )
                    }
                }
            }
        )
    }
}
