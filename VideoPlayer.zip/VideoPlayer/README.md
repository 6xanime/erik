# Video Player (Android)
Library of every video on the phone (one permission prompt), playlist, portrait/fullscreen,
audio-language + subtitle menus (embedded tracks and .srt/.vtt/.ass files). Kotlin + Jetpack Compose + Media3 ExoPlayer.

## Build
A) Android Studio: File > Open this folder > Build > Build APK(s). Install app/build/outputs/apk/debug/app-debug.apk.
B) GitHub: upload this folder to a repo (keep .github/workflows/build.yml), open Actions > Build APK > download "VideoPlayer-apk".
